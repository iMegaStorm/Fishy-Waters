#include <iostream>
#include <SFML/Graphics.hpp>

//Compiler Directives
using namespace std;
using namespace sf;

RenderWindow window(VideoMode(800, 500), "Dangerous Racing"); //the game screen

int main()
{

	//for closing the debug window when the game window is closed
	getchar();

	return 0;
}